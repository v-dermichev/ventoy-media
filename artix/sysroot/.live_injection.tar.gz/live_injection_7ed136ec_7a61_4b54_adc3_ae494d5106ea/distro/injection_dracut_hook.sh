#!/bin/sh

PATH=/ventoy/busybox:$PATH

datadir=$(ls -1 / | grep live_injection_)

[ -f /$datadir/done ] && exit 0
echo $* > /$datadir/done

# Debug: log to both initramfs and live root
echo "dracut_hook: running, datadir=$datadir" >> /$datadir/log
mkdir -p /sysroot/root
echo "dracut_hook: running, datadir=$datadir" >> /sysroot/root/live_injection.log
echo "dracut_hook: sysroot contents:" >> /sysroot/root/live_injection.log
ls -la /$datadir/ >> /sysroot/root/live_injection.log 2>&1
echo "dracut_hook: sysroot_path exists: $(test -f /$datadir/sysroot_path && echo yes || echo no)" >> /sysroot/root/live_injection.log
echo "dracut_hook: sysroot dir exists: $(test -d /$datadir/sysroot && echo yes || echo no)" >> /sysroot/root/live_injection.log

. $datadir/distro/functions.sh

copy_sysroot_to /sysroot
