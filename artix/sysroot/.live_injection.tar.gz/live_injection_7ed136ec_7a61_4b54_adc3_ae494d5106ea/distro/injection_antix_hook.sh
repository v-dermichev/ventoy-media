
ventoy_live_injection() {
    local datadir=$(ls -1 / | grep live_injection_)

    [ -f /$datadir/done ] && return
    echo $0 > /$datadir/done

    . $datadir/distro/functions.sh

    copy_sysroot_to $1
}

ventoy_live_injection $NEW_ROOT
