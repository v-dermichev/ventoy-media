#!/bin/sh

PATH=/ventoy/busybox:$PATH

datadir=$(ls -1 / | grep live_injection_)

[ -f /$datadir/done ] && exit 0
echo $* > /$datadir/done

. $datadir/distro/functions.sh

copy_sysroot_to $1
