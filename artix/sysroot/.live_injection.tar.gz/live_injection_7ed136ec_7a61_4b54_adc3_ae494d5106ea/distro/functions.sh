#!/bin/sh

get_live_uid_gid() {
    vnewroot=$1

    if [ ! -f $vnewroot/etc/passwd ]; then
        echo ""; return
    fi

    vusercnt=$(ls -1 $vnewroot/home/ | wc -l)
    if [ $vusercnt -ne 1 ]; then
        echo ""; return
    fi

    vlive=$(ls -1 $vnewroot/home/)
    grep "^$vlive" $vnewroot/etc/passwd | awk -F: '{print $3":"$4}'
}

chown_for_live() {
    vdir=$1
    vnewsys=$2

    vid=$(get_live_uid_gid $vnewsys)
    if [ -z "$vid" ]; then
        return
    fi

    volddir=$(pwd)
    cd $vdir
    find . | while read line; do
        if [ "$line" = "." ]; then
            continue
        fi

        if [ -f "$line" ]; then
            chown $vid "$line"
        elif [ -d "$line" ]; then
            vpath=${line#*/}
            if [ ! -d "$vnewsys/$vpath" ]; then
                chown $vid "$line"
            fi
        fi
    done
    cd $volddir
}

# Copy sysroot to target root, handling both classic and live directory modes.
# Usage: copy_sysroot_to <vroot>
#   vroot: target root (e.g. /new_root, /sysroot, /root)
copy_sysroot_to() {
    vroot=$1
    datadir=$(ls -1 / | grep live_injection_)

    [ -d $vroot/etc ] || return 0

    if [ -d /$datadir/sysroot ]; then
        # Classic mode: sysroot was extracted from archive
        chown_for_live "/$datadir/sysroot" $vroot
        cp -a /$datadir/sysroot/* $vroot/
        return 0
    fi

    [ -f /$datadir/sysroot_path ] || return 0

    # Live directory mode: mount Ventoy USB and copy from directory
    vtpath=$(cat /$datadir/sysroot_path | tr -d '\r\n ')
    vtmnt=""

    # Log to live OS root so it's readable after boot
    logfile=$vroot/root/live_injection.log
    mkdir -p $vroot/root

    echo "LiveInjection: live mode, sysroot_path=$vtpath" >> $logfile
    echo "LiveInjection: block devices:" >> $logfile
    ls -la /dev/vd* /dev/sd* /dev/nvme* 2>&1 >> $logfile
    echo "LiveInjection: current mounts:" >> $logfile
    mount 2>&1 >> $logfile
    echo "LiveInjection: /ventoy contents:" >> $logfile
    ls -laR /ventoy/ 2>&1 >> $logfile
    echo "LiveInjection: filesystem modules:" >> $logfile
    cat /proc/filesystems 2>&1 >> $logfile

    # Try all existing mount points first
    for mnt in $(awk '{print $2}' /proc/mounts 2>/dev/null); do
        if [ -d "$mnt/$vtpath" ]; then
            vtmnt=$mnt
            echo "LiveInjection: found $vtpath at $mnt" >> $logfile
            break
        fi
    done

    # Try mounting — Ventoy uses device mapper for the data partition
    if [ -z "$vtmnt" ]; then
        vtmnt=/ventoy_live_mnt
        mkdir -p $vtmnt
        mounted=0

        echo "LiveInjection: /dev/mapper contents:" >> $logfile
        ls -la /dev/mapper/ 2>&1 >> $logfile

        # Try device mapper, then raw partitions (p2 = VTOYEFI vfat)
        for dev in \
            $(ls /dev/mapper/ 2>/dev/null | grep -v control | sed 's|^|/dev/mapper/|') \
            /dev/vda2 /dev/sda2 /dev/sdb2 /dev/sdc2 \
            /dev/vda1 /dev/sda1 /dev/sdb1 /dev/sdc1; do
            [ -b "$dev" ] || continue
            umount $vtmnt 2>/dev/null
            echo "LiveInjection: trying $dev" >> $logfile
            # Try common filesystem types — busybox mount may not autodetect
            mtd=0
            for fstype in exfat vfat ext4 ext2; do
                mount -t $fstype -o ro $dev $vtmnt 2>>$logfile && { mtd=1; break; }
                mount -t $fstype $dev $vtmnt 2>>$logfile && { mtd=1; break; }
            done
            [ "$mtd" = "1" ] || { echo "LiveInjection: all fstypes failed for $dev" >> $logfile; continue; }
            ls $vtmnt/ >> $logfile 2>&1
            if [ -d "$vtmnt/$vtpath" ]; then
                mounted=1
                echo "LiveInjection: mounted $dev, found $vtpath" >> $logfile
                break
            fi
            umount $vtmnt 2>/dev/null
        done

        if [ "$mounted" != "1" ]; then
            echo "LiveInjection: FAILED: could not find $vtpath on any mount or partition" >> $logfile
            return 1
        fi
    fi

    echo "LiveInjection: copying from $vtmnt/$vtpath" >> $logfile
    chown_for_live "$vtmnt/$vtpath" $vroot
    cp -a $vtmnt/$vtpath/* $vroot/

    if [ "$vtmnt" = "/ventoy_live_mnt" ]; then
        umount $vtmnt 2>/dev/null
    fi
}
